package com.autodraw.lineart

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Pt(val x: Float, val y: Float)

object Tracer {

    private val DX = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)
    private val DY = intArrayOf(-1, -1, 0, 1, 1, 1, 0, -1)

    /** Gambar ke latar putih (transparan = putih), lalu ambil pikselnya. */
    private fun flatten(src: Bitmap, w: Int, h: Int): IntArray {
        val flat = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(flat)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        val px = IntArray(w * h)
        flat.getPixels(px, 0, w, 0, 0, w, h)
        flat.recycle()
        return px
    }

    private fun lum(p: Int): Int =
        (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000

    /** 1 = tinta (bagian hitam). Piksel tepi selalu 0. */
    fun binarize(src: Bitmap, w: Int, h: Int, thr: Int): ByteArray {
        val px = flatten(src, w, h)
        val out = ByteArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            if (lum(px[y * w + x]) < thr) out[y * w + x] = 1
        }
        return out
    }

    /** Bitmap pratinjau: bagian hitam jadi biru, sisanya transparan. */
    fun previewBitmap(src: Bitmap, maxSide: Int, thr: Int): Bitmap {
        val s = min(1f, maxSide.toFloat() / max(src.width, src.height))
        val w = max(2, (src.width * s).roundToInt())
        val h = max(2, (src.height * s).roundToInt())
        val px = flatten(src, w, h)
        val out = IntArray(w * h)
        for (i in px.indices) if (lum(px[i]) < thr) out[i] = 0xFF1E88E5.toInt()
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Zhang-Suen thinning: garis tebal jadi garis 1 piksel. */
    fun thin(img: ByteArray, w: Int, h: Int) {
        val del = IntArray(w * h)
        var changed = true
        while (changed) {
            changed = false
            for (pass in 0..1) {
                var n = 0
                for (y in 1 until h - 1) {
                    val row = y * w
                    for (x in 1 until w - 1) {
                        val i = row + x
                        if (img[i].toInt() == 0) continue
                        val p2 = img[i - w].toInt()
                        val p3 = img[i - w + 1].toInt()
                        val p4 = img[i + 1].toInt()
                        val p5 = img[i + w + 1].toInt()
                        val p6 = img[i + w].toInt()
                        val p7 = img[i + w - 1].toInt()
                        val p8 = img[i - 1].toInt()
                        val p9 = img[i - w - 1].toInt()
                        val b = p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9
                        if (b < 2 || b > 6) continue
                        var a = 0
                        if (p2 == 0 && p3 == 1) a++
                        if (p3 == 0 && p4 == 1) a++
                        if (p4 == 0 && p5 == 1) a++
                        if (p5 == 0 && p6 == 1) a++
                        if (p6 == 0 && p7 == 1) a++
                        if (p7 == 0 && p8 == 1) a++
                        if (p8 == 0 && p9 == 1) a++
                        if (p9 == 0 && p2 == 1) a++
                        if (a != 1) continue
                        val ok = if (pass == 0) (p2 * p4 * p6 == 0 && p4 * p6 * p8 == 0)
                        else (p2 * p4 * p8 == 0 && p2 * p6 * p8 == 0)
                        if (ok) del[n++] = i
                    }
                }
                if (n > 0) {
                    changed = true
                    for (k in 0 until n) img[del[k]] = 0
                }
            }
        }
    }

    /** Ubah skeleton jadi polyline (goresan menerus). */
    fun trace(sk: ByteArray, w: Int, h: Int, minLen: Int, eps: Float): List<List<Pt>> {
        val visited = BooleanArray(w * h)
        val result = ArrayList<List<Pt>>()

        fun nbrCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var c = 0
            for (d in 0 until 8) {
                val nx = x + DX[d]
                val ny = y + DY[d]
                if (nx in 0 until w && ny in 0 until h && sk[ny * w + nx].toInt() == 1) c++
            }
            return c
        }

        fun walk(from: Int, out: ArrayList<Int>) {
            var cur = from
            var pdx = 0
            var pdy = 0
            while (true) {
                val x = cur % w
                val y = cur / w
                var best = -1
                var bestScore = -100f
                for (d in 0 until 8) {
                    val nx = x + DX[d]
                    val ny = y + DY[d]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni].toInt() == 0 || visited[ni]) continue
                    var s = (DX[d] * pdx + DY[d] * pdy).toFloat() /
                        hypot(DX[d].toFloat(), DY[d].toFloat())
                    if (d % 2 == 0) s += 0.01f
                    if (s > bestScore) {
                        bestScore = s
                        best = d
                    }
                }
                if (best < 0) return
                cur = (y + DY[best]) * w + (x + DX[best])
                visited[cur] = true
                out.add(cur)
                pdx = DX[best]
                pdy = DY[best]
            }
        }

        fun emit(idx: List<Int>) {
            if (idx.size < minLen) return
            val pts = idx.map { Pt((it % w).toFloat(), (it / w).toFloat()) }
            result.add(simplify(pts, eps))
        }

        // 1) mulai dari ujung-ujung garis
        for (i in 0 until w * h) {
            if (sk[i].toInt() == 0 || visited[i]) continue
            if (nbrCount(i) != 1) continue
            visited[i] = true
            val path = arrayListOf(i)
            walk(i, path)
            emit(path)
        }
        // 2) sisanya (loop / cabang): jalan dua arah dari titik awal
        for (i in 0 until w * h) {
            if (sk[i].toInt() == 0 || visited[i]) continue
            visited[i] = true
            val a = ArrayList<Int>()
            walk(i, a)
            val b = ArrayList<Int>()
            walk(i, b)
            val path = ArrayList<Int>()
            for (k in b.indices.reversed()) path.add(b[k])
            path.add(i)
            path.addAll(a)
            emit(path)
        }
        return result
    }

    /** Mode isi: tiap baris, tiap potongan hitam = satu goresan horizontal. */
    fun scan(img: ByteArray, w: Int, h: Int, step: Int): List<List<Pt>> {
        val res = ArrayList<List<Pt>>()
        var y = 1
        while (y < h - 1) {
            var x = 1
            while (x < w - 1) {
                if (img[y * w + x].toInt() == 1) {
                    val s = x
                    while (x < w - 1 && img[y * w + x].toInt() == 1) x++
                    res.add(listOf(Pt(s.toFloat(), y.toFloat()), Pt(x.toFloat(), y.toFloat())))
                } else x++
            }
            y += step
        }
        return res
    }

    private fun perp(p: Pt, a: Pt, b: Pt): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len = hypot(dx, dy)
        if (len == 0f) return hypot(p.x - a.x, p.y - a.y)
        return abs(dy * (p.x - a.x) - dx * (p.y - a.y)) / len
    }

    /** Ramer-Douglas-Peucker (iteratif). */
    private fun simplify(pts: List<Pt>, eps: Float): List<Pt> {
        val n = pts.size
        if (n < 3) return pts
        val keep = BooleanArray(n)
        keep[0] = true
        keep[n - 1] = true
        val stack = ArrayList<IntArray>()
        stack.add(intArrayOf(0, n - 1))
        while (stack.isNotEmpty()) {
            val seg = stack.removeAt(stack.size - 1)
            val a = seg[0]
            val b = seg[1]
            var md = 0f
            var mi = -1
            for (i in a + 1 until b) {
                val dd = perp(pts[i], pts[a], pts[b])
                if (dd > md) {
                    md = dd
                    mi = i
                }
            }
            if (mi >= 0 && md > eps) {
                keep[mi] = true
                stack.add(intArrayOf(a, mi))
                stack.add(intArrayOf(mi, b))
            }
        }
        val out = ArrayList<Pt>()
        for (i in 0 until n) if (keep[i]) out.add(pts[i])
        return out
    }
}
