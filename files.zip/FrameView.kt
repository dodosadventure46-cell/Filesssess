package com.autodraw.lineart

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Kotak mengambang: geser di mana saja untuk memindah, tarik titik merah di pojok kanan bawah untuk resize. */
class FrameView(
    ctx: Context,
    private val onDragBy: (Int, Int) -> Unit,
    private val onResizeBy: (Int, Int) -> Unit
) : View(ctx) {

    var preview: Bitmap? = null
    var drawing = false

    private val d = ctx.resources.displayMetrics.density
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        color = 0xFFE53935.toInt()
        pathEffect = DashPathEffect(floatArrayOf(12f * d, 8f * d), 0f)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE53935.toInt() }
    private val previewPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 150 }
    private val handleR = 16f * d
    private var mode = 0
    private var lx = 0f
    private var ly = 0f
    private val tmp = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!drawing) {
            c.drawColor(0x1A2196F3)
            val bm = preview
            if (bm != null) {
                val s = min(w / bm.width, h / bm.height)
                val dw = bm.width * s
                val dh = bm.height * s
                val l = (w - dw) / 2f
                val t = (h - dh) / 2f
                tmp.set(l, t, l + dw, t + dh)
                c.drawBitmap(bm, null, tmp, previewPaint)
            }
        }
        val inset = borderPaint.strokeWidth / 2f
        tmp.set(inset, inset, w - inset, h - inset)
        c.drawRect(tmp, borderPaint)
        if (!drawing) c.drawCircle(w - handleR, h - handleR, handleR, handlePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val inHandle = e.x > width - handleR * 2.6f && e.y > height - handleR * 2.6f
                mode = if (inHandle) 2 else 1
                lx = e.rawX
                ly = e.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lx).toInt()
                val dy = (e.rawY - ly).toInt()
                if (dx != 0 || dy != 0) {
                    lx += dx
                    ly += dy
                    if (mode == 2) onResizeBy(dx, dy) else onDragBy(dx, dy)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}
